import json
import torch
import torch.nn.functional as F
import numpy as np
from scipy.signal import resample
import mne
import boto3
import io

# ------------------------- Preprocessing Functions -------------------------
def apply_bandpass(signal, sfreq, l_freq=0.3, h_freq=35.0):
    return mne.filter.filter_data(signal, sfreq=sfreq, l_freq=l_freq, h_freq=h_freq, verbose=False)

def apply_notch(signal, sfreq, freq=50.0):
    return mne.filter.notch_filter(signal, Fs=sfreq, freqs=[freq], verbose=False)

def apply_resample(signal, orig_sfreq, target_sfreq):
    num_samples = int(len(signal) * target_sfreq / orig_sfreq)
    return resample(signal, num_samples)

def preprocess_raw_1d_eeg(signal, ch=1, seq_len=30, epoch_size=200):
    total_points = signal.shape[0]
    total_epochs = total_points // (seq_len * epoch_size)
    trimmed = signal[:total_epochs * seq_len * epoch_size]
    return trimmed.reshape(total_epochs, ch, seq_len, epoch_size)

# ------------------------- Load Scripted Model -------------------------
device = torch.device("cpu")
model = torch.jit.load("model_scripted.pt", map_location=device)
model.eval()

# ------------------------- Lambda Handler -------------------------
def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        bucket = body['bucket']
        key = body['key']

        # Load EEG CSV from S3
        s3 = boto3.client('s3')
        response = s3.get_object(Bucket=bucket, Key=key)
        raw_csv = response['Body'].read()
        raw_data = np.loadtxt(io.BytesIO(raw_csv), delimiter=',', skiprows=1)

        raw_signal = raw_data[:, 1] if raw_data.ndim > 1 else raw_data

        # Preprocessing
        orig_sfreq = 250
        target_sfreq = 200
        signal = apply_notch(raw_signal, sfreq=orig_sfreq)
        signal = apply_bandpass(signal, sfreq=orig_sfreq)
        signal = apply_resample(signal, orig_sfreq, target_sfreq)
        processed_eeg = preprocess_raw_1d_eeg(signal)

        if processed_eeg.shape[0] == 0:
            raise ValueError("Not enough EEG data after preprocessing.")

        eeg_tensor = torch.tensor(processed_eeg, dtype=torch.float32).to(device)

        # Inference
        with torch.no_grad():
            logits = model(eeg_tensor)
            probs = F.softmax(logits, dim=1)
            predictions = torch.argmax(probs, dim=1)

        return {
            'statusCode': 200,
            'body': json.dumps({
                'prediction': predictions.cpu().tolist(),
                'probabilities': probs.cpu().tolist()
            })
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
